Title: 		Scheduling Application
Author:		Connor Grigg
Version: 	1.0.0
Contact: 	cgrig17@wgu.edu
Purpose:	Application to assist consulting organization to manage customers and schedule appointments for them
IDE:		Intellij IDEA Community 2020.03.1
Java Version:	openjdk version "11.0.10" 2021-01-19
		OpenJDK Runtime Environment (build 11.0.10+8)
		OpenJDK 64-Bit Server VM (build 11.0.10+8, mixed mode)
JavaFX:		java11-openjfx 11.0.10.u1-1
Run instructions:
		Load program project directory into IDEA, click the run button, and let it go!

Additional report:
		Additional reports counts total unique customers and displays this information
